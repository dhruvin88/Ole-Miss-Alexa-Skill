'use strict';
const Alexa = require('alexa-sdk');

const APP_ID = 'amzn1.ask.skill.fe7e7c5b-4a7b-401b-9ff4-68e875230436';

const SKILL_NAME = 'Ole Miss';
const HELP_MESSAGE = 'Ask me questions like What day does a semester start? What Ole Miss sports are playing today? What was the score to the baseball game yesterday?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

//update to https when available
var streamInfo = {
  title: 'Rebel Radio',
  cardContent: "Rebel Radio 92.1 FM",
  url: 'https://rebelradio.smc.olemiss.edu:8002/listen',
};

const handlers = {

  'LaunchRequest': function() {
    const speechOutput = HELP_MESSAGE;
    const reprompt = HELP_REPROMPT;

    this.response.speak(speechOutput).listen(reprompt);
    this.emit(':responseReady');
  },

  'HelloIntent': function() {
    const output = 'Hell yeah... damn right... hoddy toddy gosh almighty who ' +
      'in the hell are we... Hey!!! flim flam, bim bam Ole Miss by damn!!!'

    this.response.speak(output).cardRenderer(SKILL_NAME, output);
    this.emit(':responseReady');
  },

  'SemesterStartIntent': function() {
    // delegate to Alexa to collect all the required slots
    let filledSlots = delegateSlotCollection.call(this, function(event) {
        let result = false;
        let slots = event.request.intent.slots;

        if(slots.semester.value) {
            result = true;
        }
        return result;
    });

    // delegateSlotCollection may make an asynchronous call, so there
    // is a chance that filledSlots is null. If it's null we need to
    // stop GetLocationIntent and on the next runtime tick,
    // this.emit(':delegate') which was called from
    // delegateSlotCollection will execute.
    if (!filledSlots) {
        return;
    }

    // at this point, we know that all required slots are filled.
    let slotValues = getSlotValues(filledSlots);

    console.log(JSON.stringify(slotValues));

    semester = toTitleCase(slotValues.semester.resolved);

    var params = {
      TableName: "AcademicCal",
      ProjectionExpression: "#date, #semester, #event",
      FilterExpression: "contains(#semester, :Semester) and contains(#event, :Event)",
      ExpressionAttributeNames: {
        "#date": "Date",
        "#semester": "Semester",
        "#event": "Event"
      },
      ExpressionAttributeValues: {
        ":Event": "Classes begin",
        ":Semester": semester
      }
    };

    scanDynamoItem(params, myResult => {
      var say = '';
      myResult.forEach(function(item) {
        say = semester + " semester starts on " + item.Date
      });
      if (say == '') {
        var output = "Date is not available."
        this.response.speak(output).cardRenderer(SKILL_NAME, output);
        this.emit(':responseReady');
      } else {
        say = outputCheck(say)
        this.response.speak(say).cardRenderer(SKILL_NAME, say)
        this.emit(':responseReady');
      }
    });
    }
  },

  'SemesterEventDateIntent': function() {
    var event = this.event.request.intent.slots.event.value;
    if (this.event.request.intent.slots.semester.value) {
      var semester = this.event.request.intent.slots.semester.value;
      semester = toTitleCase(semester);
    }

    switch (event) {
      case "add date":
      case "last day to add classes":
      case "the last day to add classes":
        event = "Last day to register";
        if (semester == null) {
          var output = "Please try again and state the semester. For example, ask rebel when is finals for fall semester"
          this.response.speak(output).cardRenderer(SKILL_NAME, output);
          this.emit(':responseReady');
        } else {
          var params = {
            TableName: "AcademicCal",
            ProjectionExpression: "#date, #semester, #event",
            FilterExpression: "#semester = :Semester and contains(#event, :Event)",
            ExpressionAttributeNames: {
              "#date": "Date",
              "#semester": "Semester",
              "#event": "Event"
            },
            ExpressionAttributeValues: {
              ":Event": event,
              ":Semester": semester
            }
          };

          scanDynamoItem(params, myResult => {
            var say = '';
            myResult.forEach(function(item) {
              say = "Last day to add classes is " + item.Date + " for " + item.Semester;
            });
            if (say == '') {
              var output = "Date is not available."
              this.response.speak(output).cardRenderer(SKILL_NAME, output);
              this.emit(':responseReady');
            } else {
              say = outputCheck(say)
              this.response.speak(say).cardRenderer(SKILL_NAME, say)
              this.emit(':responseReady');
            }
          });
        }
        break;

      case "registration":
        event = "Registration";
        var params = {
          TableName: "AcademicCal",
          ProjectionExpression: "#date, #semester, #event",
          FilterExpression: "contains(#event, :Event)",
          ExpressionAttributeNames: {
            "#date": "Date",
            "#semester": "Semester",
            "#event": "Event"
          },
          ExpressionAttributeValues: {
            ":Event": event
          }
        };

        scanDynamoItem(params, myResult => {
          var say = '';
          var event = '';
          myResult.forEach(function(item) {
            var date = item.Date.replace("-", "to")
            if (event != item.Event) {
              event = item.Event
              say += item.Event + " starts on " + date + "\n"
            }
          });
          if (say == '') {
            var output = "Date is not available."
            this.response.speak(output).cardRenderer(SKILL_NAME, output);
            this.emit(':responseReady');
          } else {
            say = outputCheck(say)
            this.response.speak(say).cardRenderer(SKILL_NAME, say)
            this.emit(':responseReady');
          }
        });
        break;

      case "advising":
        event = "Advising";
        var params = {
          TableName: "AcademicCal",
          ProjectionExpression: "#date, #semester, #event",
          FilterExpression: "contains(#event, :Event)",
          ExpressionAttributeNames: {
            "#date": "Date",
            "#semester": "Semester",
            "#event": "Event"
          },
          ExpressionAttributeValues: {
            ":Event": event
          }
        };

        scanDynamoItem(params, myResult => {
          var say = '';
          var event = '';
          myResult.forEach(function(item) {
            var date = item.Date.replace("-", "to")
            if (event != item.Event) {
              event = item.Event
              say += item.Event + " starts on " + date + "\n"
            }
          });
          if (say == '') {
            var output = "Date is not available."
            this.response.speak(output).cardRenderer(SKILL_NAME, output);
            this.emit(':responseReady');
          } else {
            say = outputCheck(say)
            this.response.speak(say).cardRenderer(SKILL_NAME, say)
            this.emit(':responseReady');
          }
        });
        break;

      case "withdraw date":
      case "last day for withdraw":
      case "last day to withdraw from classes":
      case "the last day to withdraw from classes":
        event = 'Deadline for course withdrawals n';
        if (semester == null) {
          var output = "Please try again and state the semester. For example, ask rebel when is finals for fall semester"
          this.response.speak(output).cardRenderer(SKILL_NAME, output);
          this.emit(':responseReady');
        } else {
          var params = {
            TableName: "AcademicCal",
            ProjectionExpression: "#date, #semester, #event",
            FilterExpression: "#semester = :Semester and contains(#event, :Event)",
            ExpressionAttributeNames: {
              "#date": "Date",
              "#semester": "Semester",
              "#event": "Event"
            },
            ExpressionAttributeValues: {
              ":Event": event,
              ":Semester": semester
            }
          };

          scanDynamoItem(params, myResult => {
            var say = '';
            myResult.forEach(function(item) {
              say = "Last day to withdraw from classes is " + item.Date + " for " + item.Semester;
            });
            if (say == '') {
              var output = "Date is not available."
              this.response.speak(output).cardRenderer(SKILL_NAME, output);
              this.emit(':responseReady');
            } else {
              say = outputCheck(say)
              this.response.speak(say).cardRenderer(SKILL_NAME, say)
              this.emit(':responseReady');
            }
          });
        }
        break;

      case "drop date":
      case "last day for drop":
      case "last day to drop classes":
      case "the last day to drop classes":
        event = 'Mandatory drop date';
        if (semester == null) {
          var output = "Please try again and state the semester. For example, ask rebel when is finals for fall semester"
          this.response.speak(output).cardRenderer(SKILL_NAME, output);
          this.emit(':responseReady');
        } else {
          var params = {
            TableName: "AcademicCal",
            ProjectionExpression: "#date, #semester, #event",
            FilterExpression: "#semester = :Semester and contains(#event, :Event)",
            ExpressionAttributeNames: {
              "#date": "Date",
              "#semester": "Semester",
              "#event": "Event"
            },
            ExpressionAttributeValues: {
              ":Event": event,
              ":Semester": semester
            }
          };

          scanDynamoItem(params, myResult => {
            var say = '';
            myResult.forEach(function(item) {
              say = "Last day to drop classes is " + item.Date + " for " + item.Semester
            });
            if (say == '') {
              var output = "Date is not available."
              this.response.speak(output).cardRenderer(SKILL_NAME, output);
              this.emit(':responseReady');
            } else {
              say = outputCheck(say)
              this.response.speak(say).cardRenderer(SKILL_NAME, say)
              this.emit(':responseReady');
            }
          });
        }
        break;

      case "finals":
        event = 'Final';
        if (semester == null) {
          var output = "Please try again and state the semester. For example, ask rebel when is finals for fall semester"
          this.response.speak(output).cardRenderer(SKILL_NAME, output);
          this.emit(':responseReady');
        } else {
          var params = {
            TableName: "AcademicCal",
            ProjectionExpression: "#date, #semester, #event",
            FilterExpression: "#semester = :Semester and contains(#event, :Event)",
            ExpressionAttributeNames: {
              "#date": "Date",
              "#semester": "Semester",
              "#event": "Event"
            },
            ExpressionAttributeValues: {
              ":Event": event,
              ":Semester": semester
            }
          };

          scanDynamoItem(params, myResult => {
            var say = '';
            myResult.forEach(function(item) {
              var date = item.Date.replace("-", "to")
              say = "Finals week is " + date + " for " + item.Semester;
            });
            if (say == '') {
              var output = "Date is not available."
              this.response.speak(output).cardRenderer(SKILL_NAME, output);
              this.emit(':responseReady');
            } else {
              say = outputCheck(say)
              this.response.speak(say).cardRenderer(SKILL_NAME, say)
              this.emit(':responseReady');
            }
          });
        }
        break;

      case "spring break":
        event = 'SPRING BREAK';
        var params = {
          TableName: "AcademicCal",
          ProjectionExpression: "#date, #semester, #event",
          FilterExpression: "contains(#event, :Event)",
          ExpressionAttributeNames: {
            "#date": "Date",
            "#semester": "Semester",
            "#event": "Event"
          },
          ExpressionAttributeValues: {
            ":Event": event
          }
        };

        scanDynamoItem(params, myResult => {
          var say = '';
          myResult.forEach(function(item) {
            var date = item.Date.replace("-", "to")
            say = item.Event + " is " + date
          });
          if (say == '') {
            var output = "Date is not available."
            this.response.speak(output).cardRenderer(SKILL_NAME, output);
            this.emit(':responseReady');
          } else {
            say = outputCheck(say)
            this.response.speak(say).cardRenderer(SKILL_NAME, say)
            this.emit(':responseReady');
          }
        });
        break;

      default:
        var say = "Sorry I did not get that"
        this.response.speak(say).cardRenderer(SKILL_NAME, say);
        this.emit(':responseReady');
    }
  },

  'SportsListIntent': function() {
    var date = this.event.request.intent.slots.date.value;

    if (date.length == 10) {
      var dd = date.substring(8, 10)
      var yy = date.substring(2, 4)
      var mm = date.substring(5, 7)
      date = mm + "/" + dd + "/" + yy
    } else {
      date = ""
    }

    var params = {
      TableName: "Sports",
      ProjectionExpression: "#date, #sport, Summary, Event",
      FilterExpression: "#date = :Date",
      ExpressionAttributeNames: {
        "#date": "Date",
        "#sport": "SportType"
      },
      ExpressionAttributeValues: {
        ":Date": date,
      }
    };

    scanDynamoItem(params, myResult => {
      var say = '';
      myResult.forEach(function(item) {
        if (item.SportType == "Baseball" || item.SportType == "Softball" || item.SportType == "Football" ||
          item.SportType == "Men's Basketball" || item.SportType == "Women's Basketball" || item.SportType == "Women's Soccer") {
          say = say + item.Summary + " " + item.SportType + " plays " + item.Event + " at " + item.Location + ". ";
        } else {
          say = say + item.Summary + " " + item.SportType + " " + item.Event + " at " + item.Location + ". ";
        }
      });
      if (say == '') {
        var output = "No Ole Miss sporting events today."
        this.response.speak(output).cardRenderer(SKILL_NAME, output);
        this.emit(':responseReady');
      } else {
        say = outputCheck(say)
        this.response.speak(say).cardRenderer(SKILL_NAME, say);
        this.emit(':responseReady');
      }
    });
  },

  'SportScoreIntent': function() {
    var date = this.event.request.intent.slots.date.value;
    var sport = toTitleCase(this.event.request.intent.slots.sport.value);

    if (date.length == 10) {
      var dd = date.substring(8, 10)
      var yy = date.substring(2, 4)
      var mm = date.substring(5, 7)
      date = mm + "/" + dd + "/" + yy
    }
    else if (date.length == 8) {
      var yy = date.substring(0,4)
      var ww = date.substring(6,8)
      date = getSundayFromWeekNum(ww, yy)
    }
    else {
      date = ""
    }

    var params = {
      TableName: "Sports",
      ProjectionExpression: "#date, #sport, Summary, Event",
      FilterExpression: "contains(#date, :Date) and contains(#sport, :SportType)",
      ExpressionAttributeNames: {
        "#date": "Date",
        "#sport": "SportType"
      },
      ExpressionAttributeValues: {
        ":Date": date,
        ":SportType": sport
      }
    };

    scanDynamoItem(params, myResult => {
      var say = '';
      myResult.forEach(function(item) {
        var regex = /\d+/g;
        var string = item.Summary
        var score = string.match(regex)

        if (string[0] == "W") {
          say = say + item.SportType + " Won" + " aganist " + item.Event + " " + score[0] + " to " + score[1] + " "
        } else if (string[0] == "L") {
          say = say + item.SportType + " lost" + " aganist " + item.Event + " " + score[0] + " to " + score[1] + " "
        } else {
          say += ''
        }
      });
      if (say == '') {
        var output = "Score is not available."
        this.response.speak(output).cardRenderer(SKILL_NAME, output);
        this.emit(':responseReady');
      } else {
        say = outputCheck(say)
        this.response.speak(say).cardRenderer(SKILL_NAME, say)
        this.emit(':responseReady');
      }
    });
  },

  //Waiting on SSL for streaming audio link
  'PlayRadioIntent': function() {
    //this.response.speak('Enjoy.').audioPlayerPlay('REPLACE_ALL', streamInfo.url, streamInfo.url, null, 0);
    this.response.speak("This function is not available at this time").cardRenderer(SKILL_NAME, "This funcation is not available at this time");
    this.emit(':responseReady');
  },

  'AMAZON.HelpIntent': function() {
    const speechOutput = HELP_MESSAGE;
    const reprompt = HELP_REPROMPT;

    this.response.speak(speechOutput).listen(reprompt);
    this.emit(':responseReady');
  },

  'AMAZON.CancelIntent': function() {
    this.response.speak(STOP_MESSAGE);
    this.emit(':responseReady');
  },

  'AMAZON.ResumeIntent': function() {
    this.emit('PlayRadioIntent');
  },

  'AMAZON.StopIntent': function() {
    this.response.speak('Okay. I\'ve stopped the stream.').audioPlayerStop();
    this.emit(':responseReady');
  },

  'AMAZON.PauseIntent': function() {
    this.emit('AMAZON.StopIntent');
  },

  'AMAZON.FallBackIntent': function() {
    this.emit('AMAZON.HelpIntent');
  },
};

//=========================================================================================================================================
//Helper Functions
//=========================================================================================================================================

function queryDynamoItem(params, callback) {
  var AWS = require('aws-sdk');
  AWS.config.update({
    region: 'us-east-1'
  });

  var docClient = new AWS.DynamoDB.DocumentClient();

  console.log('reading item from DynamoDB table');

  docClient.query(params, (err, data) => {
    if (err) {
      console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));
    } else {
      console.log("GetItem succeeded:", JSON.stringify(data, null, 2));
      callback(data.Items);
    }
  });
}

function scanDynamoItem(params, callback) {
  var AWS = require('aws-sdk');
  AWS.config.update({
    region: 'us-east-1'
  });

  var docClient = new AWS.DynamoDB.DocumentClient();

  console.log('reading item from DynamoDB table');

  docClient.scan(params, (err, data) => {
    if (err) {
      console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));
    } else {
      console.log("GetItem succeeded:", JSON.stringify(data, null, 2));
      callback(data.Items);
    }
  });
}

function toTitleCase(str) {
  return str.replace(/\w\S*/g, function(txt) {
    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
  });
}

function outputCheck(str) {
  str = str.replace("&", " and ");
  return str
}

function getSundayFromWeekNum(weekNum, year) {
    var sunday = new Date(year, 0, (1 + (weekNum - 1) * 7));
    while (sunday.getDay() !== 0) {
        sunday.setDate(sunday.getDate() - 1);
    }
    var date =("0" + (sunday.getMonth() + 1)).slice(-2)+"/" +
    ("0"+sunday.getDate()).slice(-2);

    date = date.substring(0, date.length-1);
    return date;
}

function getSlotValues(filledSlots) {
  const slotValues = {};

  console.log(`The filled slots: ${JSON.stringify(filledSlots)}`);
  Object.keys(filledSlots).forEach((item) => {
    const name = filledSlots[item].name;

    if (filledSlots[item] &&
      filledSlots[item].resolutions &&
      filledSlots[item].resolutions.resolutionsPerAuthority[0] &&
      filledSlots[item].resolutions.resolutionsPerAuthority[0].status &&
      filledSlots[item].resolutions.resolutionsPerAuthority[0].status.code) {
      switch (filledSlots[item].resolutions.resolutionsPerAuthority[0].status.code) {
        case 'ER_SUCCESS_MATCH':
          slotValues[name] = {
            synonym: filledSlots[item].value,
            resolved: filledSlots[item].resolutions.resolutionsPerAuthority[0].values[0].value.name,
            isValidated: true,
          };
          break;
        case 'ER_SUCCESS_NO_MATCH':
          slotValues[name] = {
            synonym: filledSlots[item].value,
            resolved: filledSlots[item].value,
            isValidated: false,
          };
          break;
        default:
          break;
      }
    } else {
      slotValues[name] = {
        synonym: filledSlots[item].value,
        resolved: filledSlots[item].value,
        isValidated: false,
      };
    }
  }, this);

  return slotValues;
}

exports.handler = function(event, context, callback) {
  const alexa = Alexa.handler(event, context, callback);
  alexa.APP_ID = APP_ID;
  alexa.registerHandlers(handlers);
  alexa.execute();
};
